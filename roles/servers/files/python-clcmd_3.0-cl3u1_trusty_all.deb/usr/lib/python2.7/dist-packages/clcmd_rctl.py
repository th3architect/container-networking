#!/usr/bin/env python

from clcmd_quagga import ClCmdQuagga

class ClCmdRctl(ClCmdQuagga):

    def whatis(self):
        return "show routing control specific information"

    def description(self, prog):
        return "%s is a bash command line wrapper around Quagga's integrated " \
               "user interface shell called  vtysh, wrapping commands relevant " \
               "to routing control such as interface mgmt, RIB etc." % prog

    def see_also(self):
        return "http://www.nongnu.org/quagga/docs/docs-info.html#Zebra"

    def rosetta(self):

        VTYSH = "/usr/bin/vtysh -c "

        rctl_rosetta = [
            (" interface",
             VTYSH + "'show interface'",
             "Show information about all interfaces"),

            (" interface show",
             VTYSH + "'show interface'",
             "Show information about all interfaces"),

            ("interface show [INTERFACE]",
             VTYSH + "'show interface /2'",
             "Show interface information about specific interface"),

            ("interface show description",
             VTYSH + "'show interface description'",
             "Show interface description for all interfaces"),

            ("ip route",
             VTYSH + "'show ip route'",
             "Show current RIB"),

            ("ip route show",
             VTYSH + "'show ip route'",
             "Show current RIB"),

            ("ip route show [A.B.C.D|A.B.C.D/M]",
             VTYSH + "'show ip route /3'",
             "Show specific IPv4 route in RIB"),

            ("ip route-type show [ROUTES]",
             VTYSH + "'show ip route /3'",
             "Show routes matching IPv4 route type in RIB"),

            ("ipv6 route",
             VTYSH + "'show ipv6 route'",
             "Show current IPv6 RIB"),

            ("ipv6 route show",
             VTYSH + "'show ipv6 route'",
             "Show current IPv6 RIB"),

            ("ipv6 route show [X:X::X:X|X:X::X:X/M]",
             VTYSH + "'show ipv6 route /3'",
             "Show specific IPv6 route"),

            ("ipv6 route-type show [ROUTES]",
             VTYSH + "'show ipv6 route /3'",
             "Show specific IPv6 route"),

            ("ip nht", VTYSH + "'show ip nht'",
             "Show IP Next Hop Tracking info"),

            ("ip nht show", VTYSH + "'show ip nht'",
             "Show IP Next Hop Tracking info"),

            ("ipv6 nht", VTYSH + "'show ipv6 nht'",
             "Show IPv6 Next Hop Tracking info"),

            ("ipv6 nht show", VTYSH + "'show ipv6 nht'",
             "Show IPv6 Next Hop Tracking info"),

            ("zebra client show", VTYSH + "'show zebra client'",
             "Show details about Zebra clients (protocol daemons)"),

            ("zebra client show summary", VTYSH + "'show zebra client summary'",
             "Show summary information about Zebra clients (protocol daemons)"),
            ]

        VTYSH_TERM = "/usr/bin/vtysh -c 'conf term' -c "

        term_rosetta = [
            ("ptm-enable set", VTYSH_TERM + "'ptm-enable'",
            "enable topology checking(ptm)"),
            ("ptm-enable clear", VTYSH_TERM + "'no ptm-enable'",
            "disable topology checking(ptm)"),

            ("ip forwarding set",
             VTYSH_TERM + "'ip forwarding'",
             "Enable IPv4 forwarding"),
            ("ip forwarding clear",
             VTYSH_TERM + "'no ip forwarding'",
             "Disable IPv4 forwarding"),
            ("ipv6 forwarding set",
             VTYSH_TERM + "'ipv6 forwarding'",
             "Enable IPv6 forwarding"),
            ("ipv6 forwarding clear",
             VTYSH_TERM + "'no ipv6 forwarding'",
             "Disable IPv6 forwarding"),

            ("table set <1-255>",
             VTYSH_TERM + "'table /2'",
             "Kernel IP table to use for storing routes computed"),

            ("ip nht set resolve-via-default",
             VTYSH_TERM + "'ip nht resolve-via-default'",
             "Allow IPv4 routes to be resolved via default route, not common"),

            ("ipv6 nht set resolve-via-default",
             VTYSH_TERM + "'ipv6 nht resolve-via-default'",
             "Allow IPv6 routes to be resolved via default route, not common"),

            ("ip nht clear resolve-via-default",
             VTYSH_TERM + "'no ip nht resolve-via-default'",
             "Don't allow IPv4 routes to be resolved via default route, not common"),

            ("ipv6 nht clear resolve-via-default",
             VTYSH_TERM + "'no ipv6 nht resolve-via-default'",
             "Don't allow IPv6 routes to be resolved via default route, not common"),

            ("ip route add [A.B.C.D/M] gateway [A.B.C.D]",
             VTYSH_TERM + "'ip route /3 /5'", ""),
            ("ip route add [A.B.C.D/M] gateway [A.B.C.D] [blackhole|reject]",
             VTYSH_TERM + "'ip route /3 /5 /6'", ""),
            ("ip route add [A.B.C.D/M] gateway [A.B.C.D] distance <1-255>",
             VTYSH_TERM + "'ip route /3 /5 /7'", ""),
            ("ip route add [A.B.C.D/M] gateway [A.B.C.D] [blackhole|reject] distance <1-255>",
             VTYSH_TERM + "'ip route /3 /5 /6 /8'", ""),
            ("ip route add [A.B.C.D/M] null0",
             VTYSH_TERM + "'ip route /3 /4'", ""),
            ("ip route add [A.B.C.D/M] interface [INTERFACE]",
             VTYSH_TERM + "'ip route /3 /5'", ""),
            ("ip route add [A.B.C.D/M] interface [INTERFACE] [blackhole|reject]",
             VTYSH_TERM + "'ip route /3 /5 /6'", ""),
            ("ip route add [A.B.C.D/M] interface [INTERFACE] distance <1-255>",
             VTYSH_TERM + "'ip route /3 /5 /7'", ""),
            ("ip route add [A.B.C.D/M] interface [INTERFACE] [blackhole|reject] distance <1-255>",
             VTYSH_TERM + "'ip route /3 /5 /6 /8'", ""),
            ("ip route del [A.B.C.D/M] gateway [A.B.C.D]",
             VTYSH_TERM + "'no ip route /3 /5'", ""),
            ("ip route del [A.B.C.D/M] gateway [A.B.C.D] [blackhole|reject]",
             VTYSH_TERM + "'ip route /3 /5 /6'", ""),
            ("ip route del [A.B.C.D/M] gateway [A.B.C.D] distance <1-255>",
             VTYSH_TERM + "'no ip route /3 /5 /7'", ""),
            ("ip route del [A.B.C.D/M] gateway [A.B.C.D] [blackhole|reject] distance <1-255>",
             VTYSH_TERM + "'no ip route /3 /5 /6 /8'", ""),
            ("ip route del [A.B.C.D/M] null0",
             VTYSH_TERM + "'no ip route /3 /4'", ""),
            ("ip route del [A.B.C.D/M] interface [INTERFACE]",
             VTYSH_TERM + "'no ip route /3 /5'", ""),
            ("ip route del [A.B.C.D/M] interface [INTERFACE] [blackhole|reject]",
             VTYSH_TERM + "'no ip route /3 /5 /6'", ""),
            ("ip route del [A.B.C.D/M] interface [INTERFACE] distance <1-255>",
             VTYSH_TERM + "'no ip route /3 /5 /7'", ""),
            ("ip route del [A.B.C.D/M] interface [INTERFACE] [blackhole|reject] distance <1-255>",
             VTYSH_TERM + "'no ip route /3 /5 /6 /8'", ""),

            ("ipv6 route add [X:X::X:X/M] gateway [X:X::X:X]",
             VTYSH_TERM + "'ipv6 route /3 /5'", ""),
            ("ipv6 route add [X:X::X:X/M] gateway [X:X::X:X] [blackhole|reject]",
             VTYSH_TERM + "'ipv6 route /3 /5 /6'", ""),
            ("ipv6 route add [X:X::X:X/M] gateway [X:X::X:X] distance <1-255>",
             VTYSH_TERM + "'ipv6 route /3 /5 /7'", ""),
            ("ipv6 route add [X:X::X:X/M] gateway [X:X::X:X] [blackhole|reject] distance <1-255>",
             VTYSH_TERM + "'ipv6 route /3 /5 /6 /8'", ""),
            ("ipv6 route add [X:X::X:X/M] gateway [X:X::X:X] interface [INTERFACE]",
             VTYSH_TERM + "'ipv6 route /3 /5 /7'", ""),
            ("ipv6 route add [X:X::X:X/M] gateway [X:X::X:X] interface [INTERFACE] [blackhole|reject]",
             VTYSH_TERM + "'ipv6 route /3 /5 /7 /8'", ""),
            ("ipv6 route add [X:X::X:X/M] gateway [X:X::X:X] interface [INTERFACE] distance <1-255>",
             VTYSH_TERM + "'ipv6 route /3 /5 /7 /9'", ""),
            ("ipv6 route add [X:X::X:X/M] gateway [X:X::X:X] interface [INTERFACE] [blackhole|reject] distance <1-255>",
             VTYSH_TERM + "'ipv6 route /3 /5 /7 /8 /10'", ""),
            ("ipv6 route add [X:X::X:X/M] interface [INTERFACE]",
             VTYSH_TERM + "'ipv6 route /3 /5'", ""),
            ("ipv6 route add [X:X::X:X/M] interface [INTERFACE] [blackhole|reject]",
             VTYSH_TERM + "'ipv6 route /3 /5 /6'", ""),
            ("ipv6 route add [X:X::X:X/M] interface [INTERFACE] distance <1-255>",
             VTYSH_TERM + "'ipv6 route /3 /5 /7'", ""),
            ("ipv6 route add [X:X::X:X/M] interface [INTERFACE] [blackhole|reject] distance <1-255>",
             VTYSH_TERM + "'ipv6 route /3 /5 /6 /8'", ""),
            ("ipv6 route del [X:X::X:X/M] gateway [X:X::X:X]",
             VTYSH_TERM + "'no ipv6 route /3 /5'", ""),
            ("ipv6 route del [X:X::X:X/M] gateway [X:X::X:X] [blackhole|reject]",
             VTYSH_TERM + "'ipv6 route /3 /5 /6'", ""),
            ("ipv6 route del [X:X::X:X/M] gateway [X:X::X:X] distance <1-255>",
             VTYSH_TERM + "'no ipv6 route /3 /5 /7'", ""),
            ("ipv6 route del [X:X::X:X/M] gateway [X:X::X:X] [blackhole|reject] distance <1-255>",
             VTYSH_TERM + "'no ipv6 route /3 /5 /6 /8'", ""),
            ("ipv6 route del [X:X::X:X/M] gateway [X:X::X:X] interface [INTERFACE]",
             VTYSH_TERM + "'no ipv6 route /3 /5 /7'", ""),
            ("ipv6 route del [X:X::X:X/M] gateway [X:X::X:X] interface [INTERFACE] [blackhole|reject]",
             VTYSH_TERM + "'no ipv6 route /3 /5 /7 /8'", ""),
            ("ipv6 route del [X:X::X:X/M] gateway [X:X::X:X] interface [INTERFACE] distance <1-255>",
             VTYSH_TERM + "'no ipv6 route /3 /5 /7 /9'", ""),
            ("ipv6 route del [X:X::X:X/M] gateway [X:X::X:X] interface [INTERFACE] [blackhole|reject] distance <1-255>",
             VTYSH_TERM + "'no ipv6 route /3 /5 /7 /8 /10'", ""),
            ("ipv6 route del [X:X::X:X/M] interface [INTERFACE]",
             VTYSH_TERM + "'no ipv6 route /3 /5'", ""),
            ("ipv6 route del [X:X::X:X/M] interface [INTERFACE] [blackhole|reject]",
             VTYSH_TERM + "'no ipv6 route /3 /5 /6'", ""),
            ("ipv6 route del [X:X::X:X/M] interface [INTERFACE] distance <1-255>",
             VTYSH_TERM + "'no ipv6 route /3 /5 /7'", ""),
            ("ipv6 route del [X:X::X:X/M] interface [INTERFACE] [blackhole|reject] distance <1-255>",
             VTYSH_TERM + "'no ipv6 route /3 /5 /6 /8'", ""),

            ("ip import-table add [table-id]",
             VTYSH_TERM + "'ip import-table /3'",
             "Import routes from alternate kernel route table"),

            ("ip import-table add [table-id] distance <0-255>",
             VTYSH_TERM + "'ip import-table /3 distance /5'",
             "Import routes from alternate kernel route table"),

            ("ip import-table del [table-id]",
             VTYSH_TERM + "'no ip import-table /3'",
             "Stop importing routes from alternate kernel route table"),

            ("ip protocol set [protocol] route-map [WORD]",
             VTYSH_TERM + "'ip protocol /3 route-map /5'",
             "Filter routes sent from protocol to RIB"),

            ("ip protocol clear [protocol] route-map [WORD]",
             VTYSH_TERM + "'ip protocol /3 route-map /5'",
             "Stop filtering routes sent from protocol to RIB"),

            ("ip nht set [protocol] route-map [WORD]",
             VTYSH_TERM + "'ip nht /3 route-map /5'",
             "Filter routes used for nexthop resolution for protocol"),

            ("ip nht clear [protocol] route-map [WORD]",
             VTYSH_TERM + "'no ip nht /3'",
             "Stop filtering routes for nexthop resolution for protocol"),
            ]

        VTYSH_INTERFACE = "/usr/bin/vtysh -c 'conf term' -c "

        interface_rosetta = [
            ("interface set [INTERFACE] link-detect",
                VTYSH_INTERFACE + "'interface /2' -c ' /3'",
                "enable link-detect"),
            ("interface clear [INTERFACE] link-detect",
                VTYSH_INTERFACE + "'interface /2' -c 'no /3'",
                "disable link-detect"),

            ("interface add [INTERFACE] ip address [A.B.C.D/M]",
             VTYSH_INTERFACE + "'interface /2' -c 'ip address /5'",
             "Add IPv4 address to interface"),
            ("interface del [INTERFACE] ip address [A.B.C.D/M]",
             VTYSH_INTERFACE + "'interface /2' -c 'no ip address /5'",
             "Delete IPv4 address from interface"),

            ("interface add [INTERFACE] ipv6 address [X:X::X:X/M]",
             VTYSH_INTERFACE + "'interface /2' -c 'ipv6 address /5'",
             "Add IPv6 address to interface"),
            ("interface del [INTERFACE] ipv6 address [X:X::X:X/M]",
             VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 address /5'",
             "Add IPv6 address to interface"),

            ("interface set [INTERFACE] ipv6 nd home-agent-config-flag", 
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 nd /3'",
                "set flag in IPv6 router advertisements which " \
                "indicates to hosts that the router acts as a Home Agent " \
                "and includes a Home Agent Option"),
            ("interface clear [INTERFACE] home-agent-config-flag", 
                VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 nd /3'",
                "unset flag"),

            ("interface set [INTERFACE] ipv6 nd adv-interval-option",
             VTYSH_INTERFACE + "'interface /2' -c 'ipv6 nd adv-interval-option'",
             "include an Advertisement Interval option which indicates " \
             "to hosts the maximum time, in milliseconds, between " \
             "successive unsolicited Router Advertisements"),
            ("interface clear [INTERFACE] ipv6 nd adv-interval-option",
             VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 nd adv-interval-option'",
             "don't include an Advertisement Interval option"),

            ("interface set [INTERFACE] ipv6 nd mtu <1-10000>",
             VTYSH_INTERFACE + "'interface /2' -c 'ipv6 nd mtu /6'",
             "include an MTU (type 5) option in each RA packet to " \
             "assist the attached hosts in proper interface " \
             "configuration. The announced value is not verified " \
             "to be consistent with router interface MTU."),
            ("interface clear [INTERFACE] ipv6 nd mtu <1-10000>",
             VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 nd mtu /6'",
             "Don't advertise MTU option"),

            ("interface add [INTERFACE] ipv6 nd prefix [X:X::X:X/M]",
             VTYSH_INTERFACE + "'interface /2' -c 'ipv6 nd prefix /5'",
             "Add prefix to list of addresses advertised in ND"),
            ("interface del [INTERFACE] ipv6 nd prefix [X:X::X:X/M]",
             VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 nd prefix /5'",
             "Remove prefix to list of addresses advertised in ND"),

            ("interface set [INTERFACE] ipv6 nd ra-interval <70-100000>",
             VTYSH_INTERFACE + "'interface /2' -c 'ipv6 nd ra-interval /6'",
             "Set Router Advertisement interval (in msecs)"),
            ("interface clear [INTERFACE] ipv6 nd ra-interval",
             VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 nd ra-interval'",
             "Set Router Advertisement interval to default"),

            ("interface set [INTERFACE] ipv6 nd ra-lifetime <0-9000>",
             VTYSH_INTERFACE + "'interface /2' -c 'ipv6 nd ra-lifetime /6'",
             "Set Router Advertisement Lifetime to value (in secs)"),
            ("interface clear [INTERFACE] ipv6 nd ra-lifetime",
             VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 nd ra-lifetime'",
             "Set Router Advertisement Lifetime to default"),

            ("interface set [INTERFACE] ipv6 nd reachable-time <0-3600000>",
             VTYSH_INTERFACE + "'interface /2' -c 'ipv6 nd ra-lifetime /6'",
             "Set Router Advertisement Lifetime to value (in msecs)"),
            ("interface clear [INTERFACE] ipv6 nd ra-lifetime",
             VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 nd ra-lifetime'",
             "Set Router Advertisement Lifetime to default"),

            ("interface set [INTERFACE] ipv6 nd suppress-ra",
             VTYSH_INTERFACE + "'interface /2' -c 'ipv6 nd suppress-ra'",
             "Don't Send Router Advertisement"),
            ("interface clear [INTERFACE] ipv6 nd suppress-ra",
             VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 nd suppress-ra'",
             "Send Router Advertisement"),

            ("interface set [INTERFACE] router-preference (high|medium|low)",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 nd /3 /4'",
                "Set default router preference in IPv6 router " \
                "advertisements per RFC4191.  Default: medium"),
            ("interface clear [INTERFACE] router-preference",
                VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 nd /3'",
                "use default=medium for router-preference"),
            
            ]

        return ClCmdQuagga.rosetta(self) + rctl_rosetta + interface_rosetta + term_rosetta

    def completers(self):
       rctl_completers = {
           "interface add": self.interfaces,
           "interface del": self.interfaces,
           "interface set": self.interfaces,
           "interface clear": self.interfaces,
           "interface show": self.interfaces,
           "ip route-type show": self.route_types,
           "ipv6 route-type show": self.route_types6,
       }
       return dict(ClCmdQuagga.completers(self).items() + rctl_completers.items())

    def interfaces(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show interface' | " \
            "/bin/grep '^Interface ' | /usr/bin/cut -f2 -d ' '", shell=True)
        return out.split()

    def routes(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ip route' | " \
        "/bin/grep '^[A-Z][>\t]' | /usr/bin/cut -f2 -d' '", shell=True)
        return out.split()
    
    def route_types(self, args):
        return ['babel','connected','kernel','rip','summary', 'bgp', 'isis', 'ospf', 'static', 'supernets-only', 'table']

    def routes6(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ipv6 route' | " \
        "/bin/grep '^[A-Z][>\t]' | /usr/bin/cut -f2 -d' '", shell=True)
        return out.split()

    def route_types6(self, args):
        return ['babel','connected','kernel','ripng','summary', 'bgp', 'isis', 'ospf6', 'static']


