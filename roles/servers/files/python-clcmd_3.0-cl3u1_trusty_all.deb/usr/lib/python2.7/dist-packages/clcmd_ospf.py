#!/usr/bin/env python

from clcmd_handler import ClCmdHandler

class ClCmdOspf(ClCmdHandler):

    def whatis(self):
        return "show / manipulate OSPF routing"

    def description(self, prog):
        return "%s is a bash command line wrapper around Quagga's integrated " \
               "user interface shell called vtysh, wrapping commands relevant " \
               "to OSPFv2." % prog

    def see_also(self):
        return "http://www.nongnu.org/quagga/docs/docs-info.html#OSPFv2"

    def execute(self, prog, args):
        if not args:
            return None, self.usage(prog, args)
        out, err = self.run("grep '[ \t]*ospfd=yes' /etc/quagga/daemons")
        if not out.strip():
            return None, "ospfd is not running. Please start ospfd\n"

        return super(ClCmdOspf, self).execute(prog, args)

    def rosetta(self):

        VTYSH = "/usr/bin/vtysh -c "

        base_rosetta = [
            ("version", VTYSH + "'show version'", "show zebra version"),
            ("version show", VTYSH + "'show version'", "show zebra version"),

            ("interface", VTYSH + "'show ip ospf interface'", ""),
            ("interface show", VTYSH + "'show ip ospf interface'", ""),
            ("interface show [INTERFACE]", VTYSH + "'show ip ospf interface /2'", ""),

            ("neighbor", VTYSH + "'show ip ospf neighbor'", ""),
            ("neighbor show", VTYSH + "'show ip ospf neighbor'", ""),
            ("neighbor show all", VTYSH + "'show ip ospf neighbor all'", ""),
            ("neighbor show detail", VTYSH + "'show ip ospf neighbor detail'", ""),
            ("neighbor show [A.B.C.D]", VTYSH + "'show ip ospf neighbor /2'", ""),

            ("route", VTYSH + "'show ip ospf route'", ""),
            ("route show", VTYSH + "'show ip ospf route'", ""),

            ("router", VTYSH + "'show ip ospf'", ""),
            ("router show", VTYSH + "'show ip ospf'", ""),

            ("border-routers", VTYSH + "'show ip ospf border-routers'", ""),
            ("border-routers show", VTYSH + "'show ip ospf border-routers'", ""),

            ("database", VTYSH + "'show ip ospf database'", ""),
            ("database show", VTYSH + "'show ip ospf database'", ""),
            ("database show [TYPE]", VTYSH + "'show ip ospf database /2'", ""),

            ("debug", VTYSH + "'show debugging ospf'", ""),
            ("debug show", VTYSH + "'show debugging ospf'", ""),
            ("debug set event", VTYSH + "'debug ospf /2'", ""),
            ("debug clear event", VTYSH + "'no debug ospf /2'", ""),
            ("debug set ism", VTYSH + "'debug ospf /2'", ""),
            ("debug clear ism", VTYSH + "'no debug ospf /2'", ""),
            ("debug set lsa", VTYSH + "'debug ospf /2'", ""),
            ("debug clear lsa", VTYSH + "'no debug ospf /2'", ""),
            ("debug set nsm", VTYSH + "'debug ospf /2'", ""),
            ("debug clear nsm", VTYSH + "'no debug ospf /2'", ""),
            ("debug set nssa", VTYSH + "'debug ospf /2'", ""),
            ("debug clear nssa", VTYSH + "'no debug ospf /2'", ""),
            ("debug set packet", VTYSH + "'debug ospf /2'", ""),
            ("debug clear packet", VTYSH + "'no debug ospf /2'", ""),
            ("debug set ism [OBJECT]", VTYSH + "'debug ospf /2 /3'", ""),
            ("debug clear ism [OBJECT]", VTYSH + "'no debug ospf /2 /3'", ""),
            ("debug set lsa [OBJECT]", VTYSH + "'debug ospf /2 /3'", ""),
            ("debug clear lsa [OBJECT]", VTYSH + "'no debug ospf /2 /3'", ""),
            ("debug set nsm [OBJECT]", VTYSH + "'debug ospf /2 /3'", ""),
            ("debug clear nsm [OBJECT]", VTYSH + "'no debug ospf /2 /3'", ""),
            ("debug set packet [OBJECT]", VTYSH + "'debug ospf /2 /3 detail'", ""),
            ("debug clear packet [OBJECT]", VTYSH + "'no debug ospf /2 /3 detail'", ""),
            ("debug set zebra all", VTYSH + "'debug ospf zebra'", ""),
            ("debug clear zebra all", VTYSH + "'no debug ospf zebra'", ""),
            ("debug set zebra [OBJECT]", VTYSH + "'debug ospf /2 /3'", ""),
            ("debug clear zebra [OBJECT]", VTYSH + "'no debug ospf /2 /3'", ""),
            ("debug set all", self.debug_set_all, ""),
            ("debug clear all", self.debug_clear_all, ""),
        ]

        VTYSH_ROUTER = "/usr/bin/vtysh -c 'conf term' -c 'router ospf' -c "

        router_rosetta = [
            ("auto-cost set reference-bandwidth <1-4294967>", \
                VTYSH_ROUTER + "'auto-cost reference-bandwidth /3'",
                "this sets the reference bandwidth for cost calculations, " \
                "where this bandwidth is considered equivalent to an OSPF " \
                "cost of 1, specified in Mbits/s. The default is 100Mbit/s " \
                "(i.e. a link of bandwidth 100Mbit/s or higher will have a " \
                "cost of 1. Cost of lower bandwidth links will be scaled " \
                "with reference to this cost).  This configuration setting " \
                "MUST be consistent across all routers within the OSPF domain."),
            ("auto-cost clear reference-bandwidth", \
                VTYSH_ROUTER + "'no auto-cost reference-bandwidth'", ""),

            ("capability set opaque", VTYSH_ROUTER + "'capability opaque'", ""),
            ("capability clear opaque", VTYSH_ROUTER + "'no capability opaque'", ""),

            ("compatible set rfc1583 ",
                VTYSH_ROUTER + "'compatible rfc1583'",
                "RFC2328, the sucessor to RFC1583, suggests according " \
                "to section G.2 (changes) in section 16.4 a change to " \
                "the path preference algorithm that prevents possible " \
                "routing loops that were possible in the old version of " \
                "OSPFv2. More specifically it demands that inter-area " \
                "paths and intra-area backbone path are now of equal " \
                "preference but still both preferred to external paths.  " \
                "This command should NOT be set normally."),
            ("compatible clear rfc1583", VTYSH_ROUTER + "'no compatible rfc1583'", ""),

            ("distance set intra-area <1-255>",
             VTYSH_ROUTER + "'distance ospf intra-area /3'",
             "Define administrative distance for intra-area routes"),
            ("distance clear",
             VTYSH_ROUTER + "'no distance ospf'",
             "Restire default administrative distances for all route types"),
            ("distance set inter-area <1-255>",
             VTYSH_ROUTER + "'distance ospf inter-area /3'",
             "Define administrative distance for inter-area routes"),
            ("distance set external <1-255>",
             VTYSH_ROUTER + "'distance ospf external /3'",
             "Define administrative distance for external routes"),

            ("default-information set originate",
             VTYSH_ROUTER + "'default-information originate'",
             "Distribute a default route"),
            ("default-information set originate metric <0-16777214>",
             VTYSH_ROUTER + "'default-information originate metric /4'",
             "Distribute a default route with specified metric"),
            ("default-information set originate metric-type <1-2>",
             VTYSH_ROUTER + "'default-information originate metric-type /4'",
             "Distribute a default route with specified metric type"),
            ("default-information set originate route-map <WORD>",
             VTYSH_ROUTER + "'default-information originate route-map /4'",
             "Distribute default route with route-map"),
            ("default-information set originate metric <0-16777214> metric-type <1-2>",
             VTYSH_ROUTER + "'default-information originate metric /4 /5 /6'",
             "Distribute a default route with specified metric"),
            ("default-information set originate metric <0-16777214> metric-type <1-2> route-map <WORD>",
             VTYSH_ROUTER + "'default-information originate metric /4 /5 /6 /7 /8'",
             "Distribute a default route with specified metric, metric-type and route-map"),
            ("default-information set originate always",
             VTYSH_ROUTER + "'default-information originate always'",
             "Always distribute a default route with specified metric"),
            ("default-information clear originate",
             VTYSH_ROUTER + "'no default-information originate'",
             "Stop distributing a default route"),

            ("default-metric set <0-16777214>",
             VTYSH_ROUTER + "'default-metric /2'",
             "Set metric for redistributed routes"),
            ("default-metric clear",
             VTYSH_ROUTER + "'no default-metric'",
             "Restore default metric for redistributed routes"),

            ("distribute-list add <WORD> out [ROUTES]",
             VTYSH_ROUTER + "'distribute-list /2 /3 /4'",
             "Filter networks in routing updates"),
            ("distribute-list del <WORD> out [ROUTES]",
             VTYSH_ROUTER + "'distribute-list /2 /3 /4'",
             "Stop filtering networks in routing updates"),

            ("log-adjacency-changes set",
                VTYSH_ROUTER + "'log-adjacency-changes'",
                "configures ospfd to log changes in adjacency. With " \
                "the optional detail argument, all changes in adjacency " \
                "status are shown. Without detail, only changes to full " \
                "or regressions are shown."),
            ("log-adjacency-changes set detail",
                VTYSH_ROUTER + "'log-adjacency-changes detail'",
                "configures ospfd to log changes in adjacency. With " \
                "the optional detail argument, all changes in adjacency " \
                "status are shown. Without detail, only changes to full " \
                "or regressions are shown."),
            ("log-adjacency-changes clear", VTYSH_ROUTER + "'no log-adjacency-changes'", ""),

            ("max-metric set router-lsa administrative", VTYSH_ROUTER + "'max-metric /2 /3'", ""),
            ("max-metric clear router-lsa administrative", VTYSH_ROUTER + "'no max-metric /2 /3'", ""),
            ("max-metric set router-lsa on-shutdown <5-86400>", VTYSH_ROUTER + "'max-metric /2 /3 /4'", ""),
            ("max-metric clear router-lsa on-shutdown", VTYSH_ROUTER + "'no max-metric /2 /3'", ""),
            ("max-metric set router-lsa on-startup <5-86400>", VTYSH_ROUTER + "'max-metric /2 /3 /4'", ""),
            ("max-metric clear router-lsa on-startup", VTYSH_ROUTER + "'no max-metric /2 /3'", ""),

            ("redistribute add [ROUTES]", VTYSH_ROUTER + "'redistribute /2'", ""),
            ("redistribute del [ROUTES]", VTYSH_ROUTER + "'no redistribute /2'", ""),
            ("redistribute add [ROUTES] metric <0-16777214>", 
             VTYSH_ROUTER + "'redistribute /2 /3 /4'", ""),
            ("redistribute add [ROUTES] metric-type <1-2>", 
             VTYSH_ROUTER + "'redistribute /2 /3 /4'", ""),
            ("redistribute add [ROUTES] route-map <WORD>", 
             VTYSH_ROUTER + "'redistribute /2 /3 /4'", ""),
            ("redistribute add [ROUTES] metric <0-16777214> metric-type <1-2>",
             VTYSH_ROUTER + "'redistribute /2 /3 /4 /5 /6'", ""),
            ("redistribute add [ROUTES] metric <0-16777214> metric-type <1-2> route-map <WORD>",
             VTYSH_ROUTER + "'redistribute /2 /3 /4 /5 /6 /7 /8'", ""),

            ("router-id set [A.B.C.D]",
                VTYSH_ROUTER + "'ospf router-id /2'",
                "sets the router-ID of the OSPF process. The router-ID " \
                "may be an IP address of the router, but need not be - " \
                "it can be any arbitrary 32bit number. However it MUST " \
                "be unique within the entire OSPF domain to the OSPF " \
                "speaker - bad things will happen if multiple OSPF speakers " \
                "are configured with the same router-ID! If one is not " \
                "specified then ospfd will obtain a router-ID " \
                "automatically from zebra."),
            ("router-id clear", VTYSH_ROUTER + "'no ospf router-id'", ""),
            ("write-multiplier set <1-100>", VTYSH_ROUTER + "'write-multiplier /2'", ""),
            ("write-multiplier clear", VTYSH_ROUTER + "'no write-multiplier'", ""),
            ("abr-type set [TYPE]",
                VTYSH_ROUTER + "'ospf abr-type /2'",
                "the OSPF standard for ABR behaviour does not allow an " \
                "ABR to consider routes through non-backbone areas when " \
                "its links to the backbone are down, even when there are " \
                "other ABRs in attached non-backbone areas which still " \
                "can reach the backbone - this restriction exists primarily " \
                "to ensure routing-loops are avoided.  With the 'Cisco' or " \
                "'IBM' ABR type, the default in this release of Quagga, " \
                "this restriction is lifted, allowing an ABR to consider " \
                "summaries learnt from other ABRs through non-backbone " \
                "areas, and hence route via non-backbone areas as a last " \
                "resort when, and only when, backbone links are down.  " \
                "Note that areas with fully-adjacent virtual-links are " \
                "considered to be 'transit capable' and can always be " \
                "used to route backbone traffic, and hence are unaffected " \
                "by this setting (see OSPF virtual-link).  More information " \
                "regarding the behaviour controlled by this command can " \
                "be found in RFC 3509, Alternative Implementations of " \
                "OSPF Area Border Routers, and draft-ietf-ospf-shortcut-" \
                "abr-02.txt."),
            ("abr-type clear [TYPE]", VTYSH_ROUTER + "'no ospf abr-type /2'", ""),

            ("network add [A.B.C.D/M] area [A.B.C.D]",
                VTYSH_ROUTER + "'network /2 /3 /4'",
                "this command specifies the OSPF enabled interface(s).  " \
                "Prefix length in interface must be equal or bigger (ie. " \
                "smaller network) than prefix length in network statement."),
            ("network del [A.B.C.D/M] area [A.B.C.D]",
                VTYSH_ROUTER + "'no network /2 /3 /4'", ""),

            ("area add [A.B.C.D] range [A.B.C.D/M]",
             VTYSH_ROUTER + "'area /2 /3 /4'",
             "this command allows you to summarize routes from an area." \
             "By summarizing routes introduced to other areas, the inter-area" \
             "route tables can be reduced and churn within an area is further" \
             "prevented from affecting other areas"),
            ("area del [A.B.C.D] range [A.B.C.D/M]",
             VTYSH_ROUTER + "'no area /2 /3 /4'", ""),

            ("area add [A.B.C.D] range [A.B.C.D/M] not-advertise",
             VTYSH_ROUTER + "'area /2 /3 /4 /5'",
             "this command suppresses announcing the routes matching the range"),
            ("area del [A.B.C.D] range [A.B.C.D/M] not-advertise",
             VTYSH_ROUTER + "'no area /2 /3 /4 /5'", ""),

            ("area add [A.B.C.D] range [A.B.C.D/M] cost <cost>",
             VTYSH_ROUTER + "'area /2 /3 /4 /5 /6'",
             "this command announces a summary route with the cost specified." \
             "The summarized route from the area is announced to other areas. "\
             "The cost can be from 1-16777215"),

            ("area set [A.B.C.D] stub",
             VTYSH_ROUTER + "'area /2 /3'",
             "this command makes the area specified a stubby area." \
             "Stubby areas have smaller routing tables as external routes " \
             "are not announced into the area. In totally stubby areas, even "\
             "inter-area routes are not announced. They have a default route "\
             "pointing to the ABR. An ASBR cannot be present in a stubby or " \
             "totally stubby area. All routers in an area MUST be configured "\
             "with the same stub properties, else adjacency will not be " \
             "established"),
            ("area clear [A.B.C.D] stub",
             VTYSH_ROUTER + "'no area /2 /3'", ""),
            ("area set [A.B.C.D] stub no-summary",
             VTYSH_ROUTER + "'area /2 /3 /4'",
             "make area totally-stubby"),
            ("area clear [A.B.C.D] stub no-summary",
             VTYSH_ROUTER + "'no area /2 /3 /4'", ""),

            ("timer set throttle spf <0-600000> <0-600000> <0-600000>", \
                VTYSH_ROUTER + "'timers /2 /3 /4 /5 /6'", ""),
            ("timer clear throttle spf", \
                VTYSH_ROUTER + "'no timers /2 /3'", ""),
            ("timer set refresh <10-1800>", \
                VTYSH_ROUTER + "' /2 /0 /3'", ""),
            ("timer clear refresh", \
                VTYSH_ROUTER + "'no /2 /0'", ""),
        ]

        VTYSH_INTERFACE = "/usr/bin/vtysh -c 'conf term' -c "

        interface_rosetta = [

            ("interface set [INTERFACE] passive",
                VTYSH_ROUTER + "'passive-interface /2'",
                "do not speak OSPF interface on the given interface, " \
                "but do advertise the interface as a stub link in the " \
                "router-LSA (Link State Advertisement) for this router. " \
                "This allows one to advertise addresses on such connected " \
                "interfaces without having to originate AS-External/Type-5 " \
                "LSAs (which have global flooding scope) - as would occur " \
                "if connected addresses were redistributed into OSPF (see " \
                "Redistribute routes to OSPF). This is the only way to " \
                "advertise non-OSPF links into stub areas."),
            ("interface clear [INTERFACE] passive ",
                VTYSH_ROUTER + "'no passive-interface /2'",
                ""),

            ("interface set [INTERFACE] area [A.B.C.D]",
             VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
             "assign interface to area specified. Used with unnumbered "\
             "interfaces."),
            ("interface clear [INTERFACE] area",
             VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",""),

            ("interface set [INTERFACE] authentication message-digest",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "specify that MD5 HMAC authentication must be used " \
                "on this interface. MD5 keying material must also be " \
                "configured (see message-digest-key). Overrides any " \
                "authentication enabled on a per-area basis (see area " \
                "authentication message-digest).  Note that OSPF MD5 " \
                "authentication requires that time never go backwards " \
                "(correct time is NOT important, only that it never goes " \
                "backwards), even across resets, if ospfd is to be able " \
                "to promptly reestabish adjacencies with its neighbours " \
                "after restarts/reboots. The host should have system " \
                "time be set at boot from an external or non-volatile " \
                "source (eg battery backed clock, NTP, etc.) or else the " \
                "system clock should be periodically saved to non-volative " \
                "storage and restored at boot if MD5 authentication is to " \
                "be expected to work reliably."),
            ("interface clear [INTERFACE] authentication",
                VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
                "don't use authentication by message digest"),

            ("interface set [INTERFACE] message-digest-key [KEY-ID] md5 [KEY]",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4 /5 /6'",
                "set OSPF authentication key to a cryptographic password. " \
                "The cryptographic algorithm is MD5.  KEY-ID identifies " \
                "secret key used to create the message digest. This ID is " \
                "part of the protocol and must be consistent across " \
                "routers on a link.  KEY is the actual message digest " \
                "key, of up to 16 chars (larger strings will be " \
                "truncated), and is associated with the given KEY-ID."),
            ("interface clear [INTERFACE] authentication",
                VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
                "clear message-digest key"),

            ("interface set [INTERFACE] authentication-key [AUTH-KEY]",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "set OSPF authentication key to a simple password.  " \
                "After setting AUTH-KEY, all OSPF packets are " \
                "authenticated. AUTH-KEY has length up to 8 chars.  " \
                "Simple text password authentication is insecure " \
                "and deprecated in favour of MD5 HMAC authentication0"),
            ("interface clear [INTERFACE] authentication-key",
                VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
                "don't use authentication-key"),

            ("interface set [INTERFACE] cost <1-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "set link cost for the specified interface. The cost " \
                "value is set to router-LSA's metric field and used " \
                "for SPF calculation."),
            ("interface clear [INTERFACE] cost",
                VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
                "use default cost value"),

            ("interface set [INTERFACE] dead-interval <1-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "set number of seconds for RouterDeadInterval timer " \
                "value used for Wait Timer and Inactivity Timer. This " \
                "value must be the same for all routers attached to a " \
                "common network. The default value is 40 seconds."), 
            ("interface clear [INTERFACE] dead-interval",
                VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
                "use default value of 40 seconds"),

            ("interface set [INTERFACE] dead-interval minimal hello-multiplier <1-10>",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4 /5 /6'",
                "dead-interval is set to 1 second and one must specify " \
                "a hello-multiplier. The hello-multiplier specifies how " \
                "many Hellos to send per second, from 2 (every 500ms) " \
                "to 20 (every 50ms). Thus one can have 1s convergence " \
                "time for OSPF. If this form is specified, then the " \
                "hello-interval advertised in Hello packets is set to " \
                "0 and the hello-interval on received Hello packets is " \
                "not checked, thus the hello-multiplier need NOT be the " \
                "same across multiple routers on a common link."),
            ("interface clear [INTERFACE] dead-interval",
                VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
                "don't set a minimal multiplier"),

            ("interface set [INTERFACE] hello-interval <1-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "set number of seconds for HelloInterval timer value. " \
                "Setting this value, Hello packet will be sent every " \
                "timer value seconds on the specified interface. This " \
                "value must be the same for all routers attached to a " \
                "common network. The default value is 10 seconds.  " \
                "This command has no effect if dead-interval minimal " \
                "is also specified for the interface."),
            ("interface clear [INTERFACE] hello-interval",
                VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
                "use default value of 10 seconds"),

            ("interface set [INTERFACE] network broadcast",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "set interface network type to broadcast"),
            ("interface set [INTERFACE] network non-broadcast",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "set interface network type to non-broadcast"),
            ("interface set [INTERFACE] network point-to-multipoint",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "set interface network type to point-to-multipoint"),
            ("interface set [INTERFACE] network point-to-point",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "set interface network type to point-to-point"),
            ("interface clear [INTERFACE] network",
                VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
                "use default interface network type"),

            ("interface set [INTERFACE] priority <0-255>",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "set RouterPriority integer value. The router with " \
                "the highest priority will be more eligible to become " \
                "Designated Router. Setting the value to 0, makes the " \
                "router ineligible to become Designated Router. The " \
                "default value is 1."),
            ("interface clear [INTERFACE] priority",
                VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
                "use default priority value of 1"),

            ("interface set [INTERFACE] retransmit-interval <3-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'ip ospf /3 /4'",
                "set number of seconds for RxmtInterval timer value. " \
                "This value is used when retransmitting Database " \
                "Description and Link State Request packets. The " \
                "default value is 5 seconds."),
            ("interface clear [INTERFACE] retransmit-interval",
                VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
                "use default retransmit-interval value of 5"),

            ("interface set [INTERFACE] transmit-delay <1-65535> [A.B.C.D]",
             VTYSH_INTERFACE + "'interface /2' -c 'ip ospf transmit-delay /4 /5'",
             "set number of seconds for InfTransDelay value.  " \
             "LSAs' age should be incremented by this value when " \
             "transmitting. The default value is 1 second."),
            ("interface clear [INTERFACE] transmit-delay",
             VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf /3'",
             "use default transmit-delay value of 1"),

            ("interface set [INTERFACE] mtu-ignore [A.B.C.D]",
             VTYSH_INTERFACE + "'interface /2' -c 'ip ospf mtu-ignore /4'",
             "Disable mtu mismatch detection"),
            ("interface clear [INTERFACE] mtu-ignore [A.B.C.D]",
             VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf mtu-ignore /4'",
             "Disable mtu mismatch detection"),

            ("interface set [INTERFACE] bfd",
             VTYSH_INTERFACE + "'interface /2' -c 'ip ospf bfd'",
             "Enable BFD session on this interface and notify OSPF on state change"),
            ("interface set [INTERFACE] bfd detect-multiplier <2-255> min-rx <50-60000> min-tx <50-60000>",
             VTYSH_INTERFACE + "'interface /2' -c 'ip ospf bfd /5 /7 /9'",
             "Enable BFD session on this interface and notify OSPF on state change"),
            ("interface clear [INTERFACE] bfd",
             VTYSH_INTERFACE + "'interface /2' -c 'no ip ospf bfd'",
             "Disable BFD session associated with OSPF on this interface "),
        ]

        return ClCmdHandler.rosetta(self) + base_rosetta + router_rosetta + interface_rosetta

    def completers(self):
       ospf_completers = {
           "interface set": self.interfaces,
           "interface clear": self.interfaces,
           "interface show": self.interfaces,
           "neighbor show": self.neighbors,
           "database show": self.database,
           "debug set ism": self.debug_ism_objects,
           "debug clear ism": self.debug_ism_objects,
           "debug set lsa": self.debug_lsa_objects,
           "debug clear lsa": self.debug_lsa_objects,
           "debug set nsm": self.debug_nsm_objects,
           "debug clear nsm": self.debug_nsm_objects,
           "debug set packet": self.debug_packet_objects,
           "debug clear packet": self.debug_packet_objects,
           "debug set zebra": self.debug_ospf_zebra_objects,
           "debug clear zebra": self.debug_ospf_zebra_objects,
           "redistribute add": self.router_redistribute,
           "redistribute del": self.router_redistribute,
           "* out": self.router_redistribute,
           "abr-type set": self.router_abr_type,
           "abr-type clear": self.router_abr_type,
           "passive-interface set": self.interfaces,
           "passive-interface clear": self.interfaces,
           "area add": self.areas,
           "area del": self.areas,
           "area set": self.areas,
           "area clear": self.areas,
       }
       return dict(ClCmdHandler.completers(self).items() + ospf_completers.items())

    def interfaces(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ip ospf interface' | " \
            "/bin/grep '^[^ ]' | /usr/bin/cut -f1 -d ' '", shell=True)
        return out.split()

    def neighbors(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ip ospf neighbor all' | " \
            "/bin/grep '^[0-9]' | /usr/bin/cut -f1 -d ' '", shell=True)
        return out.split()

    def database(self, args):
        return ["asbr-summary", "external", "network", "router", \
            "summary", "nssa-external", "opaque-link", "opaque-area", \
            "opaque-as", "self-originate", "max-age"]
    def areas(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ip ospf' | " \
            "/bin/grep '^ Area' | /usr/bin/cut -f 4 -d ' '", shell=True)
        return out.split()

    def debug_ism_objects(self, args):
        return ["status", "events", "timers"]

    def debug_lsa_objects(self, args):
        return ["generate", "flooding", "install", "refresh"]

    def debug_nsm_objects(self, args):
        return ["status", "events", "timers"]

    def debug_packet_objects(self, args):
        return ["hello", "dd", "ls-request", "ls-update", "ls-ack", "all"]

    def debug_ospf_zebra_objects(self, args):
        return ["interface", "redistribute"]

    def router_redistribute(self, args):
        return ["babel", "bgp", "connected", "isis", "kernel", "rip", "static"]

    def router_abr_type(self, args):
        return ["cisco", "ibm", "shortcut", "standard"]

    def debug_all(self, args, no):
        for obj in ["event", "ism", "lsa", "nssa", "nsm", "packet", "zebra"]:
            out, err = self.run("/usr/bin/vtysh -c '%s debug ospf %s'" % (no, obj))
        for obj in self.debug_ism_objects(args):
            out, err = self.run("/usr/bin/vtysh -c '%s debug ospf ism %s'" % (no, obj))
        for obj in self.debug_lsa_objects(args):
            out, err = self.run("/usr/bin/vtysh -c '%s debug ospf lsa %s'" % (no, obj))
        for obj in self.debug_nsm_objects(args):
            out, err = self.run("/usr/bin/vtysh -c '%s debug ospf nsm %s'" % (no, obj))
        for obj in self.debug_packet_objects(args):
            out, err = self.run("/usr/bin/vtysh -c '%s debug ospf packet %s'" % (no, obj))
        for obj in self.debug_ospf_zebra_objects(args):
            out, err = self.run("/usr/bin/vtysh -c '%s debug ospf zebra %s'" % (no, obj))
        return ""

    def debug_set_all(self, args):
        return self.debug_all(args, "")

    def debug_clear_all(self, args):
        return self.debug_all(args, "no")
