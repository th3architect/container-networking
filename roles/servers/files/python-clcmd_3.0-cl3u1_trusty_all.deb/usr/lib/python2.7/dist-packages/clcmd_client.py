#!/usr/bin/env python

import socket
import pickle
import struct

UDS_SOCKET_FILE = "/usr/share/cumulus/clcmd_uds"

class ClCmdClientError(Exception): pass

class ClCmdClient(socket.socket):

    def __init__(self, prefix):
        self.prefix = prefix

        try:
            socket.socket.__init__(self, socket.AF_UNIX, socket.SOCK_STREAM)
            self.connect(UDS_SOCKET_FILE)

        except socket.error, (errno, string):
            raise ClCmdClientError("Unable to connect to server [%d]: %s\n" % (errno, string))

    def run(self, args):

        cmd_line = self.prefix + " " + " ".join(args)
        cmd_line_pickled = pickle.dumps(cmd_line, pickle.HIGHEST_PROTOCOL)

        self.sendall(cmd_line_pickled)

        size = int(struct.unpack('I', self.recv(4))[0])

        read_bytes = 0
        output = ""

        while read_bytes < size:
            output += self.recv(2048)
            read_bytes = len(output)

        out, err = pickle.loads(output)

        if err and err != '':
            raise ClCmdClientError(err)

        return out
