#!/usr/bin/env python

from clcmd_handler import ClCmdHandler

class ClCmdRa(ClCmdHandler):

    def whatis(self):
        return "show / manipulate IPv6 Router Advertisements"

    def description(self, prog):
        return "%s is a bash command line wrapper around Quagga's integrated " \
               "user interface shell called vtysh, wrapping commands relevant " \
               "to IPv6 Router Advertisements." % prog

    def see_also(self):
        return "http://www.nongnu.org/quagga/docs/docs-info.html#IPv6-Support"

    def rosetta(self):

        VTYSH = "/usr/bin/vtysh -c "

        base_rosetta = [
            ("version", VTYSH + "'show version'", "show zebra version"),
            ("version show", VTYSH + "'show version'", "show zebra version"),
        ]

        VTYSH_INTERFACE = "/usr/bin/vtysh -c 'conf term' -c "

        interface_rosetta = [
            ("interface [INTERFACE] set ra",
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd suppress-ra'",
                "send router advertisment messages"),
            ("interface [INTERFACE] clear ra",
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd suppress-ra'",
                "don't send router advertisment messages"),

            ("interface [INTERFACE] set adv-interval-option", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3'",
                "include an Advertisement Interval option which indicates " \
                "to hosts the maximum time, in milliseconds, between " \
                "successive unsolicited Router Advertisements"),
            ("interface [INTERFACE] clear adv-interval-option", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "don't include an Advertisement Interval option"),

            ("interface [INTERFACE] set home-agent-config-flag", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3'",
                "set flag in IPv6 router advertisements which " \
                "indicates to hosts that the router acts as a Home Agent " \
                "and includes a Home Agent Option"),
            ("interface [INTERFACE] clear  home-agent-config-flag", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "unset flag"),

            ("interface [INTERFACE] set managed-config-flag", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3'",
                "set flag in IPv6 router advertisements which " \
                "indicates to hosts that they should use managed " \
                "(stateful) protocol for addresses autoconfiguration " \
                "in addition to any addresses autoconfigured using " \
                "stateless address autoconfiguration"),
            ("interface [INTERFACE] clear managed-config-flag", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "unset flag"),

            ("interface [INTERFACE] set other-config-flag", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3'",
                "set flag in IPv6 router advertisements which indicates " \
                "to hosts that they should use administered (stateful) " \
                "protocol to obtain autoconfiguration information other " \
                "than addresses"),
            ("interface [INTERFACE] clear other-config-flag", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "unset flag"),

            ("interface [INTERFACE] set home-agent-lifetime <0-65520>", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4'",
                "the value to be placed in Home Agent Option, when " \
                "Home Agent config flag is set, which indicates to " \
                "hosts Home Agent Lifetime. The default value of 0 " \
                "means to place the current Router Lifetime value."),
            ("interface [INTERFACE] clear home-agent-lifetime", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "use default value of 0, the current Router Lifetime value"),

            ("interface [INTERFACE] set home-agent-preference <0-65535>", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4'",
                "the value to be placed in Home Agent Option, when " \
                "Home Agent config flag is set, which indicates to " \
                "hosts Home Agent preference. The default value of 0 " \
                "stands for the lowest preference possible."),
            ("interface [INTERFACE] clear home-agent-preference", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "use default value of 0, lowest preference possible"),

            ("interface [INTERFACE] set mtu <1-65535>", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4'",
                "include an MTU (type 5) option in each RA packet to " \
                "assist the attached hosts in proper interface " \
                "configuration. The announced value is not verified " \
                "to be consistent with router interface MTU."),
            ("interface [INTERFACE] clear mtu", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "don't advertise any MTU option"),

            ("interface [INTERFACE] set prefix X:X::X:X/M",
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4'",
                "include IPv6 prefix in router advertisements"),
            ("interface [INTERFACE] set prefix X:X::X:X/M router-address",
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4 /5'",
                "include IPv6 prefix in router advertisements, indicating " \
                "to hosts on the local link that the specified prefix " \
                "contains a complete IP address by setting R flag"),
            ("interface [INTERFACE] set prefix X:X::X:X/M off-link",
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4 /5'",
                "include IPv6 prefix in router advertisements, indicating " \
                "that advertisement makes no statement about " \
                "on-link or off-link properties of the prefix"),
            ("interface [INTERFACE] set prefix X:X::X:X/M no-autoconfig",
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4 /5'",
                "include IPv6 prefix in router advertisements, indicating " \
                "to hosts on the local link that the specified prefix " \
                "cannot be used for IPv6 autoconfiguration"),
            ("interface [INTERFACE] set prefix X:X::X:X/M <0-4294967295> <0-4294967295>",
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4 /5 /6'",
                "include IPv6 prefix in router advertisements.  Arguments: " \
                "[valid-lifetime] - the length of time in seconds during " \
                "what the prefix is valid for the purpose of on-link " \
                "determination.  [preferred-lifetime] - the length of " \
                "time in seconds during what addresses generated from " \
                "the prefix remain preferred.  Value 'infinite' " \
                "represents infinity (i.e. a value of all one bits (0xffffffff))."),
            ("interface [INTERFACE] clear prefix X:X::X:X/M", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3 /4'",
                "don't include IPv6 prefix in router advertisements"),

            ("interface [INTERFACE] set ra-interval <1-1800>", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4'",
                "The maximum time allowed between sending unsolicited " \
                "multicast router advertisements from the interface, " \
                "in seconds.  Default = 600."),
            ("interface [INTERFACE] clear ra-interval", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "use default=600 for ra-interval"),

            ("interface [INTERFACE] set ra-lifetime <1-9000>", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4'",
                "The value to be placed in the Router Lifetime field " \
                "of router advertisements sent from the interface, in " \
                "seconds. Indicates the usefulness of the router as a " \
                "default router on this interface. Setting the value " \
                "to zero indicates that the router should not be " \
                "considered a default router on this interface. Must " \
                "be either zero or between value specified with ipv6 " \
                "nd ra-interval (or default) and 9000 seconds.  " \
                "Default: 1800"),
            ("interface [INTERFACE] clear ra-lifetime", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "use default=1800 for ra-lifetime"),

            ("interface [INTERFACE] set reachable-time <1-3600000>", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4'",
                "The value to be placed in the Reachable Time field in " \
                "the Router Advertisement messages sent by the router, " \
                "in milliseconds. The configured time enables the " \
                "router to detect unavailable neighbors. The value " \
                "zero means unspecified (by this router).  Default: 0"),
            ("interface [INTERFACE] clear reachable-time", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "use default=0 for reachable-time"),

            ("interface [INTERFACE] set router-preference (high|medium|low)", 
                VTYSH_INTERFACE + "'interface /1' -c 'ipv6 nd /3 /4'",
                "Set default router preference in IPv6 router " \
                "advertisements per RFC4191.  Default: medium"),
            ("interface [INTERFACE] clear router-preference", 
                VTYSH_INTERFACE + "'interface /1' -c 'no ipv6 nd /3'",
                "use default=medium for router-preference"),
        ]

        return ClCmdHandler.rosetta(self) + base_rosetta + interface_rosetta

    def completers(self):
       ra_completers = {
           "interface": self.interfaces,
       }
       return dict(ClCmdHandler.completers(self).items() + ra_completers.items())

    def interfaces(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ipv6 ospf6 interface' | " \
            "/bin/grep '^[^ ]' | /usr/bin/cut -f1 -d ' '", shell=True)
        return out.split()
